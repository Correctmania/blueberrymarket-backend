# 🫐 BlueberryMarket — Deployment Guide
## Live in ~10 minutes, completely free

---

## What You'll Deploy

| Part | Host | Cost | Time |
|------|------|------|------|
| Backend API | Render.com | Free | ~5 min |
| Frontend | Netlify | Free | ~2 min |

---

## STEP 1 — Upload Backend to GitHub

1. Go to **https://github.com** and sign in (create a free account if needed)
2. Click the **+** button → **New repository**
3. Name it: `blueberrymarket-backend`
4. Set to **Public**, click **Create repository**
5. On your computer, open a terminal in the `blueberrymarket-backend` folder and run:

```bash
git init
git add .
git commit -m "Initial BlueberryMarket backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/blueberrymarket-backend.git
git push -u origin main
```

> Replace `YOUR_USERNAME` with your actual GitHub username.

---

## STEP 2 — Deploy Backend to Render

1. Go to **https://render.com** and sign up (use your GitHub account — easiest)
2. Click **New +** → **Web Service**
3. Click **Connect a repository** → select `blueberrymarket-backend`
4. Render will auto-detect settings from `render.yaml`. Confirm:
   - **Name:** `blueberrymarket-api`
   - **Build Command:** `npm install`
   - **Start Command:** `node src/server.js`
5. Click **Create Web Service**
6. Wait ~3 minutes for it to build and deploy
7. **Copy your backend URL** — it will look like:
   ```
   https://blueberrymarket-api.onrender.com
   ```

### After deploy — seed the database:
In Render dashboard → your service → **Shell** tab, run:
```bash
npm run seed
```
This creates:
- Admin account: `admin@blueberrymarket.com` / `Admin@12345`
- Demo account: `demo@blueberrymarket.com` / `Demo@12345`

### Test your backend is live:
Open in browser: `https://blueberrymarket-api.onrender.com/health`
You should see: `{"status":"ok","service":"BlueberryMarket API",...}`

---

## STEP 3 — Update Frontend with Your Backend URL

Open `blueberrymarket-frontend/index.html` in any text editor.

Find this line (around line 582):
```javascript
const API = window.BLUEBERRY_API_URL || 'http://localhost:3001/api';
```

Replace it with your actual Render URL:
```javascript
const API = 'https://blueberrymarket-api.onrender.com/api';
```

Save the file.

---

## STEP 4 — Deploy Frontend to Netlify

### Option A — Drag & Drop (Easiest, 60 seconds)
1. Go to **https://app.netlify.com/drop**
2. Drag the entire `blueberrymarket-frontend` **folder** onto the page
3. Done! Netlify gives you a URL like:
   ```
   https://amazing-babbage-abc123.netlify.app
   ```
4. Optional: Click **Site settings** → **Change site name** → set it to `blueberrymarket`
   Your URL becomes: `https://blueberrymarket.netlify.app`

### Option B — GitHub (Enables auto-deploy on changes)
1. Create a new GitHub repo: `blueberrymarket-frontend`
2. Push the frontend folder to it
3. In Netlify → **New site** → **Import from Git** → connect the repo
4. Build settings: leave blank (it's a static HTML file)
5. Click **Deploy**

---

## STEP 5 — You're Live! 🎉

Share these links:
- **Frontend:** `https://blueberrymarket.netlify.app`
- **Backend API:** `https://blueberrymarket-api.onrender.com`

---

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| 👑 Admin | admin@blueberrymarket.com | Admin@12345 |
| 🧪 Demo | demo@blueberrymarket.com | Demo@12345 |

**Change these immediately after first login!**

---

## Important Notes

### Free Tier Limitations
- **Render free tier** spins down after 15 minutes of inactivity
  - First request after idle takes ~30 seconds to wake up
  - Upgrade to Render's $7/month plan to avoid this
- **Netlify free tier** is 100GB bandwidth/month (more than enough)

### Custom Domain (Optional)
- In Netlify → **Domain settings** → **Add custom domain**
- In Render → **Settings** → **Custom Domains**
- Point your domain's DNS to both services

### Environment Variables (Render Dashboard)
Go to your Render service → **Environment** tab to change:
- `JWT_SECRET` — auto-generated, leave it
- `REFERRAL_BONUS_USD` — default `10`
- `TRADING_FEE` — default `0.001` (0.1%)
- `MIN_DEPOSIT_USD` — default `10`

### Keeping Data Persistent
Render's free tier has an **ephemeral filesystem** — data resets on each deploy.
To persist data, upgrade to a paid plan OR switch to a hosted database:
1. Create a free **MongoDB Atlas** cluster at mongodb.com/atlas
2. Install mongoose: `npm install mongoose`
3. (Contact developer to integrate MongoDB adapter)

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| Backend URL returns error | Wait 30s — Render free tier wakes up slowly |
| CORS error in browser | Make sure you updated the API URL in index.html |
| Login fails | Run `npm run seed` in Render Shell tab |
| Frontend shows blank | Check browser console for JS errors |
| Prices not loading | Check backend /health endpoint is reachable |

---

## API Endpoints Quick Reference

Once live, your API is at `https://blueberrymarket-api.onrender.com/api/`

```
GET  /api/health              → Server status
GET  /api/market/prices       → All crypto prices
POST /api/auth/register       → Create account
POST /api/auth/login          → Sign in
GET  /api/wallet/balance      → Portfolio (auth)
POST /api/trade/buy           → Buy crypto (auth)
POST /api/trade/sell          → Sell crypto (auth)
GET  /api/admin/dashboard     → Admin stats (admin)
```

Full docs: see `API_DOCS.md` in the backend folder.

---

*Built with ❤️ — BlueberryMarket v1.0.0*
